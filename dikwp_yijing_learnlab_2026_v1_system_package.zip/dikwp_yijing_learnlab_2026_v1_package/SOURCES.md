# Sources and Learning Corpus

Classical corpus and reference categories:
- 《周易》经文：卦辞与爻辞。
- 《易传》十翼：彖、象、系辞、文言、说卦、序卦、杂卦等。
- 传统注疏：王弼、孔颖达、程颐、朱熹等。
- 现代研究：经学史、哲学史、出土文献、数字人文和跨文化研究。

All teaching materials should distinguish original text, commentary, modern scholarship, teacher explanation, learner reflection, and AI-generated drafts.
