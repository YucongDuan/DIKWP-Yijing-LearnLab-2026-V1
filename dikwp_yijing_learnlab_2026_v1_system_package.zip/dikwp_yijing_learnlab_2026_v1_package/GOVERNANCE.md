# Governance Boundary

## Allowed
- classical text learning
- trigram and hexagram structure exercises
- commentary comparison
- cultural history and philosophy education
- non-predictive reflective journaling
- teacher-reviewed classroom use

## Prohibited
- paid fortune-telling claims
- medical, legal, financial, marriage, exam, employment, or crisis decisions
- frightening or manipulating learners with “bad fate” labels
- AI-fabricated ancient sources
- diagnosing mental state, health, or family destiny
- replacing professional advice

## Kill Conditions
Stop the workflow if the learner asks for high-stakes prediction, self-harm guidance, medical/legal/financial advice, coercive relationship advice, or if the AI output lacks textual source verification.
