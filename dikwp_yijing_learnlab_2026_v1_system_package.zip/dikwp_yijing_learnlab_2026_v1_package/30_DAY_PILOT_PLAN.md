# 30-Day Pilot Plan

## Week 1: Boundary and basic literacy
- freeze non-fortune-telling boundary
- learn yin-yang, eight trigrams, 64 hexagrams, and jing/zhuan distinction
- build first Evidence Ledger

## Week 2: Text and structure
- read 8 representative hexagrams
- draw six-line structures and changing lines
- compare two commentaries

## Week 3: Interpretation workshop
- run non-predictive reflective cases
- register observer boundary, purpose, evidence, residual, and kill conditions
- test AI hallucination and overclaim scenarios

## Week 4: Teaching or research output
- produce a Learning Passport, teaching module, or small digital-humanities dataset
- conduct human teacher review
- archive evidence and AI Use Log
