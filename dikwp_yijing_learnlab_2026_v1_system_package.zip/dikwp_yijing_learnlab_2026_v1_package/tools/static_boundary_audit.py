#!/usr/bin/env python3
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[1]
PATTERNS=[(r"\brequests\.",'network'),(r"\burllib\.request",'url'),(r"\bsocket\.",'socket'),(r"\beval\(",'eval'),(r"\bexec\(",'exec'),(r"os\.system",'shell')]
findings=[]
for p in ROOT.rglob('*'):
    if not p.is_file() or p.name=='static_boundary_audit.py' or p.suffix.lower() not in {'.py','.html','.js','.json'}: continue
    txt=p.read_text(encoding='utf-8',errors='ignore')
    for pat,meaning in PATTERNS:
        if re.search(pat,txt,re.I):findings.append({'file':str(p.relative_to(ROOT)),'meaning':meaning})
res={'package':'DIKWP Yijing LearnLab 2026 V1','findings':findings,'network_or_dynamic_execution_detected':bool(findings),'note':'No network, payment, divination service, or high-stakes decision adapter is included.'}
(ROOT/'static_boundary_audit_report.json').write_text(json.dumps(res,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(res,ensure_ascii=False,indent=2))
