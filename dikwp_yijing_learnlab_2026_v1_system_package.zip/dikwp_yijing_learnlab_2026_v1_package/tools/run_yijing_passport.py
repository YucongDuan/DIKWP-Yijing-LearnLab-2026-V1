#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
from datetime import datetime, timezone

def main():
    p=argparse.ArgumentParser();p.add_argument('note',type=Path);p.add_argument('--out',type=Path,default=Path('outputs'));args=p.parse_args()
    note=json.loads(args.note.read_text(encoding='utf-8'))
    passport={'version':'DIKWP Yijing LearnLab 2026 V1 CLI','generated_at':datetime.now(timezone.utc).isoformat(),'note':note,'boundaries':{'fortune_telling_claim':False,'medical_legal_financial_advice':False,'human_teacher_review_required':True},'next_steps':['verify original text','compare at least two commentaries','write residuals and kill conditions','conduct oral explanation']}
    args.out.mkdir(parents=True,exist_ok=True);target=args.out/'yijing_learning_passport.json';target.write_text(json.dumps(passport,ensure_ascii=False,indent=2),encoding='utf-8')
    print('DIKWP Yijing LearnLab');print('Output:',target);print('Boundary: cultural learning only; no fortune-telling or high-stakes advice.')
if __name__=='__main__':main()
